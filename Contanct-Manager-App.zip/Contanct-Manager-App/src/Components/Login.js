import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import ContactService from "../../src/Components/Services/ContactService";
let Login = () => {

    let navigate = useNavigate()

    let [state, setState] = useState({
        loading: false,
        contact: {
            name: '',
            profilePhoto: '',
            email: '',
            gender: "",
            state: ''
        },
    })

    useEffect(() => {
        let fetchData = async () => {
            try {
                setState({ ...state, loading: true })
                let response = await ContactService.getAllGroups()
                // console.log(response.data);
                setState({
                    ...state,
                    loading: false,
                    groups: response.data
                })
            }
            catch (error) {
                setState({
                    ...state,
                    loading: false,
                    errorMeassage: error.message
                })
            }
        }
        fetchData()
    }, [])

    let updateInput = (event) => {
        setState({
            ...state,
            contact: {
                ...state.contact,
                [event.target.name]: event.target.value
            }
        })
    }
    const handleFileInputChange = (event) => {
        const file = event.target.files[0];
        setState((state) => ({
            ...state,
            profilePhoto: file,
        }));
    };

    let submitForm = (event) => {
        event.preventDefault();
        let fetchData = async () => {
            try {
                let response = await ContactService.createContact(contact)
                if (response) {
                    navigate('/contacts/list', { replace: true })
                }
            }
            catch (error) {
                setState({ ...state, errorMeassage: error.message })
                navigate('/contacts/add', { replace: false })
            }
        }
        fetchData()
    }

    let { contact, groups } = state;

    return (
        <React.Fragment>
            <section className="add-contact">
                <div className="container mt-2">
                    <div className="row">
                        <div className="col">
                            <h1 className="fw-bold">Add Contact</h1>
                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Modi quibusdam at libero vel veniam necessitatibus delectus. Expedita numquam minus ipsum. Neque at vel recusandae eius magnam expedita enim laborum necessitatibus.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className="new-contact">
                <div className="container mt-5">
                    <div className="row">
                        <div className="col-md-4">
                            <form action="" onSubmit={submitForm}>
                                <div className="mb-2">
                                    <input
                                        required={true}
                                        name="name"
                                        value={contact.name}
                                        onChange={updateInput}
                                        type="text" className="form-control" placeholder="Name" />
                                </div>
                                <div className="mb-2">
                                    <div>
                                        <label htmlFor="profilePhoto">Profile Photo:</label>
                                    </div>
                                    <input
                                        type="file"
                                        id="profilePhoto"
                                        name="profilePhoto"
                                        onChange={handleFileInputChange}
                                        accept="image/*"
                                        required
                                    />
                                </div>
                                <div className="mb-2">
                                    <input
                                        required={true}
                                        name="email"
                                        value={contact.email}
                                        onChange={updateInput}
                                        type="email" className="form-control" placeholder="Email" />
                                </div>
                                <div className="mb-2">
                                    <div>
                                        <label>Gender</label>
                                    </div>
                                    <label htmlFor="male">Male</label>
                                    <input className="me-2" type="radio" id="male" name="gender" value="male" checked={contact.gender === "male"} onChange={updateInput} />
                                    <label className="ms-2" htmlFor="female">Female</label>
                                    <input type="radio" id="female" name="gender" value="female" checked={contact.gender === "female"} onChange={updateInput} />
                                </div>
                                <label htmlFor="state">State:</label>
                                <select id="state" name="state" value={contact.state} onChange={updateInput} required>
                                    <option value="">Please select your state</option>
                                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                    <option value="Assam">Assam</option>
                                    <option value="Bihar">Bihar</option>
                                    <option value="Chhattisgarh">Chhattisgarh</option>
                                    <option value="Goa">Goa</option>
                                    <option value="Gujarat">Gujarat</option>
                                    <option value="Haryana">Haryana</option>
                                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                                    <option value="Jharkhand">Jharkhand</option>
                                    <option value="Karnataka">Karnataka</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                                    <option value="Maharashtra">Maharashtra</option>
                                    <option value="Manipur">Manipur</option>
                                    <option value="Meghalaya">Meghalaya</option>
                                    <option value="Mizoram">Mizoram</option>
                                    <option value="Nagaland">Nagaland</option>
                                    <option value="Odisha">Odisha</option>
                                    <option value="Punjab">Punjab</option>
                                    <option value="Rajasthan">Rajasthan</option>
                                    <option value="Sikkim">Sikkim</option>
                                    <option value="Tamil Nadu">Tamil Nadu</option>
                                    <option value="Telangana">Telangana</option>
                                    <option value="Tripura">Tripura</option>
                                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                                    <option value="Uttarakhand">Uttarakhand</option>
                                    <option value="West Bengal">West Bengal</option>
                                </select>
                                <div className="mb-2">
                                    <input type="submit" className="btn btn-success" value="Create" />
                                    <Link to={'/contacts/list'} className="btn btn-dark">Cancel</Link>
                                </div>
                            </form>
                        </div>
                        <div className="col-md-8">
                            <img src="https://i.pinimg.com/736x/89/90/48/899048ab0cc455154006fdb9676964b3.jpg" className="img-fluid contact-img" alt="" />
                        </div>
                    </div>
                </div>
            </section>
        </React.Fragment>
    )
}

export default Login;