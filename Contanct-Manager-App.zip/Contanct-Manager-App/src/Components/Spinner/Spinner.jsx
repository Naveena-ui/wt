import React from "react";
import spinnerImg from '../../assets/images/loadingImg.gif'

let Spinner = () => {
    return(
        <React.Fragment>
            <div>
                <img src={spinnerImg} className="d-block m-auto w-25 h-25" alt="" />
            </div>
        </React.Fragment>
    )
}

export default Spinner;