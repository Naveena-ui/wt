import React from "react";
import { Link } from "react-router-dom";

let NavBar = () => {
    return(
        <React.Fragment>
            <nav className="navbar navbar-dark bg-dark navbar-expand-sm">
                {/* <a href="" className="navbar-brand">Contact-Manger-App</a> */}
                <Link to={'/'} className="navbar-brand">Todo List</Link>
            </nav>
        </React.Fragment>
    )
}

export default NavBar;