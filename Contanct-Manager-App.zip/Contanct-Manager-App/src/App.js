import './App.css';
import React from 'react';
import NavBar from './Components/NavBar/NavBar';
import { Routes, Route, Navigate } from 'react-router-dom';
import ContactList from './Components/Contacts/ContactList/ContactList';
import AddContact from './Components/Contacts/AddContact/AddContact';
import UpdateContact from './Components/Contacts/UpdateContact/UpdateContact';
import Login from './Components/Login';


function App() {
  return (
    <React.Fragment>
      <NavBar/>
      <Routes>
        <Route path='/' element={<Navigate to ={'/login'}/>}></Route>
        <Route path='/contacts/list' element={<ContactList/>}></Route>
        <Route path='/contacts/add' element={<AddContact/>}></Route>
        <Route path='/contacts/update/:contactId' element={<UpdateContact/>}></Route>
        <Route path='/login' element={<Login/>}></Route>  
      </Routes>
    </React.Fragment>
  );
}

export default App;
